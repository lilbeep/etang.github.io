const Betting = artifacts.require("Betting");
const BigNumber = require('bignumber.js');


contract("Betting", (accounts) => {
	
	let instance;
	
	beforeEach(async () => {
		instance = await Betting.new("Competitor 1", "Competitor 2", { from: accounts[0] });
		});
		it("should start a round with two competitors using startRound", async () => {
			await instance.startRound("Competitor 3", "Competitor 4", { from: accounts[0] });
			const competitor1 = await instance.competitor1();
			const competitor2 = await instance.competitor2();
			assert.equal(competitor1, "Competitor 3");
			assert.equal(competitor2, "Competitor 4");
		});

    it("should allow a user to place a bet", async () => {
      // Start the round
      await instance.startRound("Competitor 3", "Competitor 4", { from: accounts[0] });
  
      // Place a bet
      const competitor = 1;
      const betAmount = web3.utils.toWei("0.00000000000000001", "ether");
      console.log(betAmount);
      console.log(await web3.eth.getBalance(accounts[1]));
      await instance.placeBet(competitor, betAmount, { from: accounts[1]});
  
      // Check that the bet was placed
      const bet = await instance.bets(0);
      assert.equal(bet.bettor, accounts[1]);
      assert.equal(bet.amount, betAmount);
      assert.equal(bet.competitor, competitor);
    });


    it("should lock bets with lockBets", async () => {
      await instance.startRound("Competitor 3", "Competitor 4", { from: accounts[0] });
      await instance.lockBets({ from: accounts[0] });
      const bettingLocked = await instance.bettingLocked();
      assert.equal(bettingLocked, true);
    });

    it("should not allow bets to be placed while locked", async () => {
      await instance.startRound("Competitor 3", "Competitor 4", { from: accounts[0] });
      await instance.lockBets({ from: accounts[0] });
      try {
        const competitor = 1;
        const betAmount = web3.utils.toWei("0.00000000000000001", "ether");
        await instance.placeBet(competitor, betAmount, { from: accounts[1]});
        assert.fail("Expected error not thrown");
      } catch (error) {
        assert.include(
          error.message,
          "revert Betting is locked, wait till next round",
          "Betting was not locked"
        );
      }
    });

    it("should complete a round with completeRound", async () => {
      await instance.completeRound(1, { from: accounts[0] });
      const winner = await instance.winner();
      assert.equal(winner, 1);
    });

    it("should distribute winnings with distributeWinnings", async () => {
      await instance.startRound("Competitor 3", "Competitor 4", { from: accounts[0] });
      const competitor = 1;
      const betAmount = web3.utils.toWei("0.00000000000000001", "ether");
      await instance.placeBet(competitor, betAmount, { from: accounts[1]});
      await instance.placeBet(2, betAmount, { from: accounts[2]});
      await instance.lockBets({ from: accounts[0] });
      await instance.completeRound(1, { from: accounts[0] });
      const initialBalance1 = await web3.eth.getBalance(accounts[1]);
      const initialBalance2 = await web3.eth.getBalance(accounts[2]);
      await instance.settleBets({ from: accounts[0] });
      const finalBalance1 = await web3.eth.getBalance(accounts[1]);
      const finalBalance2 = await web3.eth.getBalance(accounts[2]);
      const gasPrice = await web3.eth.getGasPrice();
      const gasUsed = 0.5e6;
      const expectedPayout = (betAmount * 2) - (gasPrice * gasUsed);
      assert.approximately(finalBalance1 - initialBalance1, expectedPayout, 1000, "Winnings not distributed correctly");
      assert.approximately(finalBalance2 - initialBalance2, expectedPayout, 1000, "Winnings not distributed correctly");
    });
    

    it("should refund bets", async () => {
      const betAmount = web3.utils.toWei("0.1", "ether");
      await instance.startRound("Competitor 1", "Competitor 2");
      await instance.placeBet(true, { value: betAmount, from: accounts[1] });
      await instance.placeBet(false, { value: betAmount, from: accounts[2] });
      const initialBalance1 = await web3.eth.getBalance(accounts[1]);
      const initialBalance2 = await web3.eth.getBalance(accounts[2]);
      await instance.refundBets({ from: accounts[0] });
      const finalBalance1 = await web3.eth.getBalance(accounts[1]);
      const finalBalance2 = await web3.eth.getBalance(accounts[2]);
      assert.equal(finalBalance1 - initialBalance1, betAmount, "Bet amount not refunded correctly");
      assert.equal(finalBalance2 - initialBalance2, betAmount, "Bet amount not refunded correctly");
    });
})